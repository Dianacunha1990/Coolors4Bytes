import { useState } from "react";

export function ColorGenerate() {
  const [color, setColour] = useState("");
  const rgb = () => Math.floor(Math.random() * 256);
  const rgbToHex = (r, g, b) =>
    "#" +
    [r, g, b]
      .map((x) => {
        const hex = x.toString(16);
        return hex.length === 1 ? "0" + hex : hex;
      })
      .join(" ");

  const handleGenerate = () => {
    const color = {
      r: rgb(),
      g: rgb(),
      b: rgb(),
    };
    setColour(rgbToHex(color.r, color.g, color.b));
  };

  return (
    <div>
      <button onClick={handleGenerate}>{color}</button>
    </div>
  );
}

export default ColorGenerate;