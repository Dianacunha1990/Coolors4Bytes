import "./App.css";
import { PrettyColors } from "./components/PrettyColors";

function App() {
  return (
    <div>
      <PrettyColors></PrettyColors>
    </div>
  );
}

export default App;
